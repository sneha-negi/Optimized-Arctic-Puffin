/*
  CEC17 Test Function Suite for Single Objective Optimization- Bound constraints 
  Noor Awad (email: noor0029@e.ntu.edu.sg) 
  Last update on 29_6_2017
*/

Please put cec17_func.cpp and input_data folder with your algorithm in the same folder. Set this folder as the current path.
get lower bound, upperbound, dimensions, function by calling the CEC2017.m file:
[lb,ub,dim,fobj] = CEC2017(function_name)

function name is from 'F1' to 'F30' skipping 'F2' as it is deleted

